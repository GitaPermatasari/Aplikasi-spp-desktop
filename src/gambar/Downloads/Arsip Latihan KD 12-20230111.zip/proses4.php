<?php

// 1. menampung  data dari form disimpan dalam var local 
$angka=$_POST['txtangka'];

// melakukan looping dari 1 s.d 10
for($awal=1;$awal<=100;$awal++){
	// menghitungn perkalian
	
	$hasilKali = $awal * $angka;
	// menampilkan di layar
	echo $awal.' x '.$angka.' = ' . $hasilKali.'<br/>';
}
