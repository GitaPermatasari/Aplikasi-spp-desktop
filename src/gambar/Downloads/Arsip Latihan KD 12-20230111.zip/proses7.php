<?php

// 1. menampung  data dari form disimpan dalam var local 
$angka=$_POST['txtangka'];

// 2. menampung  data dari form disimpan dalam var local 
$proses=$_POST['txtJmlProses'];

for($awal=1;$awal<=$proses;$awal++){
	
	$hasilKali = $awal * $angka;
	
	// menampilkan di layar
	echo $awal.' x '.$angka.' = ' . $hasilKali.'<br/>';

}
