<body>
  <center>
<h1 align="center">~ 💖 Welcome I'M Putra💖 ~</h1>
<br>
<div align="center">
  </a>
    <br>
  <p>PUTRAMODZ</p>
  <p>hidup itu sementara kawan</p>
  <p>Apa Yang Perlu Kamu sombongkan?</p>
<p>Alwys Bersyukur yaa ><</p>
<p><a href="https://youtube.com/@Putra_Modz_">- subscribe ya</a><p>
  
</div>
    <div align="center">
<!-- <img src="https://i.imgur.com/jx17oHT.gif"> -->
      </div>
<div>
<h2 align="center"> 🐱 ~ Tentang Saya ~ 🐱 </h2>
  <div align="center">
<img src="https://64.media.tumblr.com/e1f1c97123ae217eb731500e502e0083/tumblr_n9dxcikmIU1qc9zfzo7_r1_250.gif" align="right">
  </div>
<li>
 <b>Name:</b> Putra</li>
<li>
<b>Umur:</b> 18 YearsOld
</li>
<li>
<b>Skils:</b> Html,Js,C++
</li>
<li>
<b>Gender:</b> Laki-Laki
</li>
<li>
<b>Id Server</b> 72.838.42
</li>
<li>
<b>Hobby:</b> Mangan,turu,Ngoding,Pacar amellll 
</li>
<li>
<b>Working @:</b> Pt Sejahtra PDI :V
</li>
<br><br><br>
</div>
<div>
<h2 align="center">            ~ 📇 Welcome 📇 ~</h2>
 <br>
<p>
  <div align="center">
<img src="https://i.pinimg.com/originals/8d/4b/77/8d4b77c44b7a68c0fd609411e2c0ec3c.gif" align="right">
  </div>
</div>
<div>
  <br>
<p align="center"><img src="https://img.shields.io/badge/adobe%20photoshop%20-%2331A8FF.svg?&style=for-the-badge&logo=adobe%20photoshop&logoColor=white"/> <img src="https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white"/> <img src="https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white"/><br>
 <img src="https://img.shields.io/badge/node.js%20-%2343853D.svg?&style=for-the-badge&logo=node.js&logoColor=white"/> <img src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E"/> <img src="https://img.shields.io/badge/git%20-%23F05033.svg?&style=for-the-badge&logo=git&logoColor=white"/> <br><br>
gw juga Pandai Membuat sesuatu jika kalian Membutuhkan jasa saya bisa chat la ye :)
</p>
<br>
<h2 align="center">           📝 ~ Contactme ~ 📝</h2>
  <div align="center">
<img src="https://i.imgur.com/KXx0cCx.gif" align="right" width="373.5px" height="208.5px">
  </div>
<br>
<p align="center">jan Lupa Tetap Bersemangat >~< wkkw</p>
<p align="center"><a href="https://twitter.com/PoolPartyAkali" target="_blank"><img src="https://img.shields.io/badge/PwoolPwatyAkwali%20-%231DA1F2.svg?&style=for-the-badge&logo=Twitter&logoColor=white"/></a> <a href="https://discord.me/cozythighs" target="_blank"><img src="https://img.shields.io/badge/CowzyThwighs%20-%237289DA.svg?&style=for-the-badge&logo=discord&logoColor=white"/></a></p>
</div>
<br>
<div>
<h2 align="center">💖 ~ thnx for read ~ 💖</h2>
<div align="center">
<img src="https://i.imgur.com/tzYKRfd.gif">
</div>
<hr>
</div>
</div>
    </center>
</body>
