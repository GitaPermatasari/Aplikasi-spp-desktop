<!doctype html>
<html lang="en">
	<head>
		<title>Form Pendaftaran</title>   <!-- ubah -->
	</head>
	<body>
		<h4>Pendaftaran Ekskul</h4>  <!-- ubah -->
			<form method="POST" action="proses5.php">  <!-- ubah -->			
			<p>Nama Lengkap<br/> <!-- ubah -->
				<input type="text" name="txtNama" autocomplete="off"/> <!-- ubah -->
			</p>	
			<p>Tempat Lahir<br/> <!-- ubah -->
				<input type="text" name="txtTempat Lahir" autocomplete="off"/> <!-- ubah -->
			</p>	
			<p>Tanggal Lahir<br/> <!-- ubah -->
				<select name="txtTanggal">
					<?php
					// ++ operator increment --> nilainya naik 1 1
					for($tgl=1;$tgl<=31;$tgl++){
						echo '<option value="'.$tgl.'">'.$tgl.'</option>';
					}					
					?>	
				</select>
				<select name="txtBulan">
					<?php
					for($bln=1;$bln<=12;$bln++){
						echo '<option value="'.$bln.'">'.$bln.'</option>';
					}					
					?>	
				</select>
				<select name="txtTahun">
					<?php
					// -- operator decrement --> nilainya turun 1 1
					for($thn=2021;$thn>=2016;$thn--){
						echo '<option value="'.$thn.'">'.$thn.'</option>';
					}					
					?>	
				</select>
			<p>
				<button type="submit">Daftar !</button> <!-- ubah -->
			</p>
			</form>	
	</body>
</html>




