//let { MessageType } = require('@adiwajshing/baileys')
let { MessageType } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn, text, participants }) => {
  let users = participants.map(u => u.jid)
  m.reply(text + '\n Hai Saya AmeliaBotz-MD Jangan Lupa Suscribe Youtube ZeroBotz-MD Official\n\nAtau bisa klik link Youtube : https://youtube.com/@Putra_Modz_ ', null, {
    contextInfo: { mentionedJid: users }
  })
}
handler.command = ['zyko-md']

handler.admin = false
handler.group = false

export default handler
