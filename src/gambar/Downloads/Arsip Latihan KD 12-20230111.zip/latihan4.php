<!doctype html>
<html lang="en">
	<head>
		<title>Membuat Perkalian dengan  Looping For</title>   <!-- ubah -->
	</head>
	<body>
		<h4>Perkalian dengan looping</h4>  <!-- ubah -->
			<form method="POST" action="proses4.php">  <!-- ubah -->
			
			<p>Masukan angka yang akan dikalikan<br/> <!-- ubah -->
				<input type="text" name="txtangka" autocomplete="off"/> <!-- ubah -->
			</p>	
			
			<p>
				<button type="submit">Kalikan !</button> <!-- ubah -->
			</p>
			
			</form>	
	</body>
</html>



