<!doctype html>
<html lang="en">
	<head>
		<title>Data Pendaftar</title>   
	</head>
	<body>
		<h1>Tabel data pendaftar</h1>		
		<table border="1">
			<thead>
				<th>No</th>
				<th>Nama</th>
				<th>Asal Sekolah</th>
			</thead>
			<tbody>
			<?php
				for($awal=1;$awal<=100;$awal++){
			?>
				<tr>
					<td> &nbsp; </td>
					<td> &nbsp; </td>
					<td> &nbsp; </td>
				</tr>
			<?php
			}
			?>
			</tbody>
		</table>	
	</body>
</html>
