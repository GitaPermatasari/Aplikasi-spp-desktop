<?php

// var local 	-->		var POST
$nilai			=		$_POST['txtNilai'];


// A. if 1 kondisi True / False saja
// if($nilai >= 75 ){
//	echo 'Selamat anda lulus dengan nilai '.$nilai;
// }



// B. if 2 kondisi True dan False saja

/*
if($nilai >= 75 ){
	echo 'Selamat anda lulus dengan nilai '.$nilai;
} else {
	echo 'Maaf anda tidak  lulus dengan nilai '.$nilai;
}
*/

// C. if n kondisi  (4)  --> 1 IF, 1 Else, n-2 else if

/*
if($nilai > 100 ){
	echo 'Maaf nilai '.$nilai. ' terlalu tinggi';
} else if ($nilai < 0) {
	echo 'Maaf nilai '.$nilai. ' terlalu rendah';	
} else if ($nilai >= 75) {
	echo 'Selamat anda lulus dengan nilai '.$nilai;
} else {
	echo 'Maaf anda tidak  lulus dengan nilai '.$nilai;	
}
*/

// D. IF Bersarang / Nested IF

if(is_numeric($nilai)){
	if($nilai > 100 ){
		echo 'Maaf nilai '.$nilai. ' terlalu tinggi';
	} else if ($nilai < 0) {
		echo 'Maaf nilai '.$nilai. ' terlalu rendah';	
	} else if ($nilai >= 75) {
		echo 'Selamat anda lulus dengan nilai '.$nilai;
	} else {
		echo 'Maaf anda tidak  lulus dengan nilai '.$nilai;	
	}
} else {
	echo 'Maaf anda salah input nilai'; 	
}












