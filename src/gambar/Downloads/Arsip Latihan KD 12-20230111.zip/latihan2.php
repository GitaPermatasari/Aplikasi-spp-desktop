<!doctype html>
<html lang="en">
	<head>
		<title>Latihan Switch Case</title>
	</head>
	<body>
		<h4>Pengecekan Grade Nilai</h4>
			<form method="POST" action="proses2.php">
			
			<p>Masukan nilai<br/>
				<input type="text" name="txtNilai" autocomplete="off"/>
			</p>	
			
			<p>
				<button type="submit">Cek Nilai</button>
			</p>
			
			</form>	
	</body>
</html>

