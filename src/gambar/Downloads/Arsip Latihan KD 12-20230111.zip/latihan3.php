<!doctype html>
<html lang="en">
	<head>
		<title>Latihan Looping For</title>
	</head>
	<body>
		<h4>Pengecekan Grade Nilai</h4>
			<form method="POST" action="proses3.php">
			
			<p>Masukan kalimat<br/>
				<input type="text" name="txtKalimat" autocomplete="off"/>
			</p>	
			
			<p>
				<button type="submit">Proses</button>
			</p>
			
			</form>	
	</body>
</html>


