<?php
// 1. membuat variabel untuk menampung nilai dari form latihan2.php

$nilai=strtoupper($_POST['txtNilai']);  // strtoupper() -> merubah huruf kecil menjadi kapital

// mengecek nilai
switch($nilai){
	case ($nilai=='A') :
	   $kalimat = 'Nilai '.$nilai.' Grade = Sangat Baik';
	break;
	   
	case ($nilai=='B') :
	   $kalimat = 'Nilai '.$nilai.' Grade =  Baik';
	break;	
	
	case ($nilai=='C') :
	   $kalimat = 'Nilai '.$nilai.' Grade =  Cukup';
	break;	
		
	case ($nilai=='D') :
	   $kalimat = 'Nilai '.$nilai.' Grade =  Kurang';
	break;	

	case ($nilai=='E') :
	   $kalimat = 'Nilai '.$nilai.' Grade =  Sangat Kurang';
	break;	
	// blok dijalankan jika tidak mengetik [A][a] - [F][f]
	default :
	   $kalimat = 'Mohon diinput A - F';	
}
	// menampilkan nilai
	echo $kalimat;
