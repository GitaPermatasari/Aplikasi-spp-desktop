<?php

// 1. menampung  data dari form disimpan dalam var local 
$stop_a=$_POST['txtJmlProses'];

// 2. menampung  data dari form disimpan dalam var local 
$stop_b=$_POST['txtangka'];

echo '<h2>Tabel Perkalian</h2>';
echo '<table border="1">';
	for($a=1;$a<=$stop_a;$a++){
	echo '<tr>';
		for($b=1;$b<=$stop_b;$b++){
			$hasilKali=$a * $b;
			echo '<td>'.$a.' x '.$b.'='.$hasilKali.'</td>';
		}
	echo '<tr>';
	}
echo '</table>';
?>
