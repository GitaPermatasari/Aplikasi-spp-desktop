<!doctype html>
<html lang="en">
	<head>
		<title>Latihan IF</title>
	</head>
	<body>
		<h4>Pengecekan Kelulusan</h4>
			<form method="POST" action="proses1.php">
			
			<p>Masukan nilai<br/>
				<input type="text" name="txtNilai"/>
			</p>	
			
			<p>
				<button type="submit">Cek Nilai</button>
			</p>
			
			</form>	
	</body>
</html>
