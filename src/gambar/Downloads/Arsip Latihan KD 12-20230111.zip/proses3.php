<?php

// buat var kalimat untuk nampung kalimat dari form latihan3.php

$kalimat=$_POST['txtKalimat'];

for($awal=1;$awal<=10;$awal++){       // ++ operator increment , -- operator decrement
	
	echo 'Loop ke-'.$awal.' - '.$kalimat.'<br/>';
}
