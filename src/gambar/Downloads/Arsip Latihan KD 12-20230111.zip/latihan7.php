<!doctype html>
<html lang="en">
	<head>
		<title>Membuat Perkalian dengan  Looping For</title>   
	</head>
	<body>
		<h4>Perkalian dengan looping</h4>  
			<form method="POST" action="proses7.php">  <!-- ubah -->
			
			<p>Masukan angka yang akan dikalikan<br/> 
				<input type="text" name="txtangka" autocomplete="off"/> 
			</p>	
			

			<p>Berapa kali di proses<br/> 
				<input type="text" name="txtJmlProses" autocomplete="off"/> 
			</p>	

			<p>
				<button type="submit">Kalikan !</button> <!-- ubah -->
			</p>
			
			</form>	
	</body>
</html>



